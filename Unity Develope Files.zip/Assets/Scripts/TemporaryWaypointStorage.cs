using UnityEngine;
using System.Collections.Generic;

public class TemporaryWaypointStorage : MonoBehaviour
{
        public static List<WaypointData> SavedWaypoints = new List<WaypointData>();
        public static CircuitType SelectedCircuit = CircuitType.None;
}
