using UnityEngine;
using UnityEngine.UI;

public class CircuitSelector : MonoBehaviour
{
    public Button circuit1Button;
    public Button circuit2Button;

    private Color defaultColor = Color.white;
    private Color selectedColor = new Color(1f, 0.5f, 0f); // taronja

    private void Start()
    {
        circuit1Button.onClick.AddListener(() => SelectCircuit(1));
        circuit2Button.onClick.AddListener(() => SelectCircuit(2));
        ResetButtonColors();
    }

    private void SelectCircuit(int index)
    {
        TemporaryWaypointStorage.SelectedCircuit = (index == 1) ? CircuitType.Circuit1 :
                                                   (index == 2) ? CircuitType.Circuit2 : CircuitType.None;
        Debug.Log("Selected circuit: " + TemporaryWaypointStorage.SelectedCircuit);

        circuit1Button.image.color = (index == 1) ? selectedColor : defaultColor;
        circuit2Button.image.color = (index == 2) ? selectedColor : defaultColor;
    }

    private void ResetButtonColors()
    {
        circuit1Button.image.color = defaultColor;
        circuit2Button.image.color = defaultColor;
    }
}
