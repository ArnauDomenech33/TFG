using System;
using System.IO.Ports;
using System.Net.Sockets;
using JetBrains.Annotations;
using UnityEngine;
using UnityEngine.UI;
using csDronLink;
using System.Collections.Generic;
using UnityEngine.SceneManagement;

public class DronMAVLinkScript : MonoBehaviour
{
    public bool useSimulation = true;
    private bool isConnected = false;
    private bool isTelemetryActive = false;

    public Toggle SimulationToggle;
    public Toggle ProductionToggle;

    public Button ConnectButton;
    public Text ConnectionStatusText;
    private Image buttonImage;
    public InputField ComInputField;
    public Text ComErrorTextLabel;

    private SerialPort serialPort;
    private TcpClient tcpClient;
    private NetworkStream tcpStream;

    public float latitude;
    public float longitude;
    public float altitude;
    public float heading;

    public Text LongitudeText;
    public Text LatitudeText;
    public Text AltitudeText;
    public Text HeadingText;

    public static DronMAVLinkScript Instance { get; private set; }


    Dron miDron = new Dron();

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(this.gameObject);
    }

    void Start()
    {
        FindUIElements();
        if (ConnectButton != null)
            buttonImage = ConnectButton.GetComponent<Image>();

        if (SimulationToggle != null && ProductionToggle != null)
        {
            SimulationToggle.onValueChanged.AddListener(OnSimulationToggleChanged);
            ProductionToggle.onValueChanged.AddListener(OnProduccionToggleChanged);
            SimulationToggle.isOn = true;
            ProductionToggle.isOn = false;
            useSimulation = true;
        }
    }
    private void OnSimulationToggleChanged(bool isOn)
    {
        if (isOn)
        {
            ProductionToggle.isOn = false;
            useSimulation = true;
            Debug.Log("Connection mode: Simulation");
            if (ConnectButton != null) ConnectButton.interactable = true;
            if (ComErrorTextLabel != null) ComErrorTextLabel.text = "";
        }
    }

    private void OnProduccionToggleChanged(bool isOn)
    {
        if (isOn)
        {
            SimulationToggle.isOn = false;
            useSimulation = false;
            Debug.Log("Connection mode: Production (real drone)");
            ValidateComInput();
        }
    }

     private void ValidateComInput()
    {
        if (ComInputField == null || ComErrorTextLabel == null || ConnectButton == null) return;

        string input = ComInputField.text.Trim();

        if (!int.TryParse(input, out int comNumber) || comNumber < 1 || comNumber > 10)
        {
            ComErrorTextLabel.text = "❌ Enter a COM number between 1 and 10.";
            ConnectButton.interactable = false;
        }
        else
        {
            ComErrorTextLabel.text = "";
            ConnectButton.interactable = true;
        }
    }

   private void FindUIElements()
    {
        if (LatitudeText == null)
            LatitudeText = GameObject.Find("LatitudeText")?.GetComponent<Text>();
        if (LongitudeText == null)
            LongitudeText = GameObject.Find("LongitudeText")?.GetComponent<Text>();
        if (AltitudeText == null)
            AltitudeText = GameObject.Find("AltitudeText")?.GetComponent<Text>();
        if (HeadingText == null)
            HeadingText = GameObject.Find("HeadingText")?.GetComponent<Text>();
        if (ConnectionStatusText == null)
            ConnectionStatusText = GameObject.Find("ConnectionStatusText")?.GetComponent<Text>();
        if (ConnectButton == null)
            ConnectButton = GameObject.Find("ConnectButton")?.GetComponent<Button>();
        if (ConnectButton != null && buttonImage == null)
            buttonImage = ConnectButton.GetComponent<Image>();
        if (ComInputField == null)
            ComInputField = GameObject.Find("ComInputField")?.GetComponent<InputField>();
        if (ComErrorTextLabel == null)
            ComErrorTextLabel = GameObject.Find("ComErrorTextLabel")?.GetComponent<Text>();

        if (isConnected && ConnectionStatusText != null && buttonImage != null)
        {
            ConnectionStatusText.text = "DISCONNECT";
            buttonImage.color = Color.red;
        }
    }


    public void ConnectButton_Clicked()
    {
        if (!isConnected)
        {
            ConnectDrone();
        }
        else
        {
            DisconnectDrone();
        }
    }

    public void ConnectDrone()
    {
        try
        {
            if (useSimulation)
            {
                miDron.Conectar("simulacion");
                Debug.Log("Connected to TCP");
            }
             else
            {
                if (ComInputField == null)
                {
                    Debug.LogError("COM input field not found.");
                    return;
                }

                string input = ComInputField.text.Trim();
                if (!int.TryParse(input, out int comNumber) || comNumber < 1 || comNumber > 10)
                {
                    ComErrorTextLabel.text = "❌ Invalid COM number.";
                    ConnectButton.interactable = false;
                    return;
                }

                string port = "COM" + comNumber;
                miDron.Conectar("produccion", port);
                Debug.Log("Connected to Drone on port " + port);
            }

            isConnected = true;
            isTelemetryActive = true;
            if (buttonImage != null) buttonImage.color = Color.red;
            if (ConnectionStatusText != null) ConnectionStatusText.text = "DISCONNECT";

            miDron.EnviarDatosTelemetria(TelemetryProcess);
        }
        catch (Exception ex)
        {
            Debug.LogError("Error opening connection: " + ex.Message);
            ComErrorTextLabel.text = "❌ Failed to connect. Check COM port.";
            ConnectButton.interactable = false;
        }
    }

    private void TelemetryProcess(List<(string name, float value)> telemetry)
    {
        if (!isTelemetryActive) return;

        foreach (var t in telemetry)
        {
            if (t.name == "Lat") latitude = t.value / 10000000f;
            if (t.name == "Lon") longitude = t.value / 10000000f;
            if (t.name == "Alt") altitude = t.value;
            if (t.name == "Heading") heading = t.value / 100f;
            Debug.Log($" {LatitudeText.text} {LongitudeText.text} {AltitudeText.text} {HeadingText.text}");
        }
    }

    private bool uiElementsLoaded = false; // per a que no se borren les dades de telemetria al canviar descena
    void Update() //Creo una funcio per actualitzar les TextLabels de la telemetria ja que Unity no permet modificar UI desde fils secundaris
    //Updatees un metode especial de unity que s'executa una vegada per frame.
    {
        if (!uiElementsLoaded)
        {
            FindUIElements();
            uiElementsLoaded = true;
        }

         if (ComInputField != null && ComErrorTextLabel != null)
        {
            string input = ComInputField.text.Trim();

            if (useSimulation)
            {
                if (!string.IsNullOrEmpty(input))
                {
                    ComErrorTextLabel.text = "ℹ️ COM input is not required in simulation mode.";
                }
                else
                {
                    ComErrorTextLabel.text = "";
                }

                if (ConnectButton != null) ConnectButton.interactable = true;
            }
            else
            {
                // Validar COM si estamos en producción
                if (!int.TryParse(input, out int comNumber) || comNumber < 1 || comNumber > 10)
                {
                    ComErrorTextLabel.text = "❌ Enter a COM number between 1 and 10.";
                    if (ConnectButton != null) ConnectButton.interactable = false;
                }
                else
                {
                    ComErrorTextLabel.text = "";
                    if (ConnectButton != null) ConnectButton.interactable = true;
                }
            }
        }

        if (isTelemetryActive)
        {
            if (LatitudeText != null) LatitudeText.text = "Latitude: " + latitude.ToString("F5") + "º";
            if (LongitudeText != null) LongitudeText.text = "Longitude: " + longitude.ToString("F5") + "º";
            if (AltitudeText != null) AltitudeText.text = "Altitude: " + altitude.ToString("F2") + "m";
            if (HeadingText != null) HeadingText.text = "Heading: " + heading.ToString("F1") + "º";
        }
    }

    public void DisconnectDrone()
    {
        try
        {
            if (useSimulation && tcpClient != null && tcpClient.Connected)
            {
                tcpStream?.Close();
                tcpClient?.Close();
                tcpStream = null;
                tcpClient = null;
                Debug.Log("Disconnected from MAVLink via TCP");
            }
            else if (!useSimulation && serialPort != null && serialPort.IsOpen)
            {
                serialPort.Close();
                serialPort = null;
                Debug.Log("Disconnected from MAVLink via Serial");
            }

            isConnected = false;
            isTelemetryActive = false;

            if (buttonImage != null) buttonImage.color = Color.green;
            if (ConnectionStatusText != null) ConnectionStatusText.text = "CONNECT";

            if (LatitudeText != null) LatitudeText.text = "Latitude: null";
            if (LongitudeText != null) LongitudeText.text = "Longitude: null";
            if (AltitudeText != null) AltitudeText.text = "Altitude: null";
            if (HeadingText != null) HeadingText.text = "Heading: null";
        }
        catch (Exception ex)
        {
            Debug.LogError("Disconnection failed: " + ex.Message);
        }

        Debug.Log("Connection finished");
    }
}
