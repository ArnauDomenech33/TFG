using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.Globalization;

public class WaypointMenuScript : MonoBehaviour
{
    public InputField LatitudeInputField;
    public InputField LongitudeInputField;
    public InputField AltitudeInputField;

    public Button AddWaypointButton;
    public Button DeleteWaypointButton;

    public Transform waypointsListContent; 
    public GameObject waypointListItemPrefab; 

    public Text errorText;
    public Slider HeadingSlider;
    public Text HeadingValueText;

    private int waypointCounter = 1;
    private List<GameObject> visualListItems = new List<GameObject>();

    private void Start()
    {
        AddWaypointButton.onClick.AddListener(OnAddWaypoint);
        DeleteWaypointButton.onClick.AddListener(OnDeleteWaypoint);
        HeadingSlider.onValueChanged.AddListener(OnHeadingSliderChanged);

        LatitudeInputField.onValueChanged.AddListener(delegate { ValidateInputs(); });
        LongitudeInputField.onValueChanged.AddListener(delegate { ValidateInputs(); });
        AltitudeInputField.onValueChanged.AddListener(delegate { ValidateInputs(); });

        ValidateInputs();
    }

    void ValidateInputs()
    {
        errorText.text = ""; // Clear previous error

        string latText = LatitudeInputField.text.Replace(",", ".");
        string lonText = LongitudeInputField.text.Replace(",", ".");
        string altText = AltitudeInputField.text.Replace(",", ".");

        bool valid = true;

        if (!float.TryParse(latText, NumberStyles.Float, CultureInfo.InvariantCulture, out float lat))
        {
            errorText.text = "❌ Invalid latitude. Use decimal format (e.g. 41.276471).";
            valid = false;
        }
        else if (lat < -90f || lat > 90f)
        {
            errorText.text = "⚠️ Latitude must be between -90 and 90.";
            valid = false;
        }

        if (!float.TryParse(lonText, NumberStyles.Float, CultureInfo.InvariantCulture, out float lon))
        {
            errorText.text = "❌ Invalid longitude. Use decimal format.";
            valid = false;
        }
        else if (lon < -180f || lon > 180f)
        {
            errorText.text = "⚠️ Longitude must be between -180 and 180.";
            valid = false;
        }

        if (!float.TryParse(altText, NumberStyles.Float, CultureInfo.InvariantCulture, out float alt))
        {
            errorText.text = "❌ Invalid altitude. Use a positive number.";
            valid = false;
        }
        else if (alt < 0)
        {
            errorText.text = "⚠️ Altitude must be positive.";
            valid = false;
        }

        AddWaypointButton.interactable = valid;
    }

    void OnHeadingSliderChanged(float value)
    {
        if (HeadingValueText != null)
            HeadingValueText.text = $"{value:F0}°";
    }

    void OnAddWaypoint()
    {
        
        errorText.text = "";

        string latText = LatitudeInputField.text.Replace(",", ".");
        string lonText = LongitudeInputField.text.Replace(",", ".");
        string altText = AltitudeInputField.text.Replace(",", ".");

        if (!float.TryParse(latText, NumberStyles.Float, CultureInfo.InvariantCulture, out float lat) ||
            !float.TryParse(lonText, NumberStyles.Float, CultureInfo.InvariantCulture, out float lon) ||
            !float.TryParse(altText, NumberStyles.Float, CultureInfo.InvariantCulture, out float alt))
        {
            errorText.text = "❌ Error parsing inputs. Check all fields.";
            return;
        }

        float head = HeadingSlider.value;

        WaypointData data = new WaypointData(lat, lon, alt, head);
        TemporaryWaypointStorage.SavedWaypoints.Add(data);

        string label = $"WP {waypointCounter}: ({lat}, {lon}, {alt}, {head}°)";
        AddWaypointListItem(label);
        waypointCounter++;
    }

    void OnDeleteWaypoint() //borra lultim waypoint
    {
       if (visualListItems.Count == 0) return;

        GameObject lastItem = visualListItems[visualListItems.Count - 1];
        Destroy(lastItem);
        visualListItems.RemoveAt(visualListItems.Count - 1);

        if (TemporaryWaypointStorage.SavedWaypoints.Count > 0)
        {
            TemporaryWaypointStorage.SavedWaypoints.RemoveAt(TemporaryWaypointStorage.SavedWaypoints.Count - 1);
            Debug.Log("Removed last saved waypoint.");
        }

        waypointCounter = Mathf.Max(1, waypointCounter - 1);
    }
    
    void AddWaypointListItem(string label)
    {
        GameObject item = Instantiate(waypointListItemPrefab, waypointsListContent);
        item.GetComponent<Text>().text = label;
        visualListItems.Add(item);
    }
}