using UnityEngine;
using System.Collections.Generic;
using Unity.VisualScripting;

public class DronePositionSync : MonoBehaviour
{
    public Transform droneObject;      // per a mostrar el dron girat
    public Transform cameraRig;        // per a moure la camara sense girarla 
    public Transform waypointsContainer;

    private float baseLat;
    private float baseLon;
    private float baseHeading;
    private bool baseSet = false; //agafo les primeres coordenades com a punt inicial per a posteriorment calcular la posicio
    

    void Update()
    {
        var droneTelemetry = DronMAVLinkScript.Instance;
        if (droneTelemetry == null || droneObject == null) return;

        float lat = droneTelemetry.latitude;
        float lon = droneTelemetry.longitude;
        float alt = droneTelemetry.altitude;
        float heading = droneTelemetry.heading;

        if (!baseSet)
        {
            baseLat = lat;
            baseLon = lon;
            baseHeading = heading;
            baseSet = true;
        }

        float latDiff = (lat - baseLat) * 111000f; // Aproximacio: 1° lat ~ 111km
        float lonDiff = (lon - baseLon) * 111000f * Mathf.Cos(lat * Mathf.Deg2Rad);

        Vector3 dronePosition = new Vector3(-lonDiff, -alt, -latDiff);
        Quaternion droneRotation = Quaternion.Euler(0f, heading, 0f);

        droneObject.position = dronePosition;
        droneObject.rotation = droneRotation;
        cameraRig.position = dronePosition;
        cameraRig.rotation = droneRotation;

        if (waypointsContainer != null)
        {
            waypointsContainer.position = dronePosition;
            waypointsContainer.rotation = Quaternion.Euler(0f, -heading, 0f); // gira lobjecte de waypoints container en mes de los waypoints que se creen, arreglarho    
        }

        Debug.Log(dronePosition + " Posicio drone");
        Debug.Log(droneRotation + " Rotacio drone");
        Debug.Log(waypointsContainer.position + " Posicio waypointscontainer");
        Debug.Log(waypointsContainer.rotation + " Rotacio waypoinstcontainer ");
        Debug.Log(heading + " Rotacio drone");
    }
    public void SpawnWaypointsFromButton()
    {
        var waypointManager = FindFirstObjectByType<WaypointManager>();
        if (waypointManager != null && baseSet)
        {
            waypointManager.SpawnWaypoints(droneObject.position, baseLat, baseLon, baseHeading);
            //Debug.Log("Base coordinates: " + baseLat + baseLon);
        }
    }
}
