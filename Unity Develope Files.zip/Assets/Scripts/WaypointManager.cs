using UnityEngine;
using System.Collections.Generic;

public struct WaypointData //Struct per a guardar les dades dels waypoints provinents dels inputfields
    {
        public float latitudeInput;
        public float longitudeInput;
        public float altitudeInput;
        public float headingInput;

        public WaypointData(float latInput, float lonInput, float altInput, float headInput)
        {
            latitudeInput = latInput;
            longitudeInput = lonInput;
            altitudeInput = altInput;
            headingInput = headInput;
        }
    }

public enum CircuitType { None, Circuit1, Circuit2 }

public class WaypointManager : MonoBehaviour
{
    public GameObject waypointPrefab;
    public Transform waypointsContainer;
    public Vector3[] waypointPositions; //Waypoints escrits manualment a l'inspector
    private List<WaypointData> waypointDataList = new List<WaypointData>(); //Waypoints escrits al menu del joc


    private List<GameObject> spawnedWaypoints = new List<GameObject>();
    private bool waypointsSpawned = false;

    private List<WaypointData> circuit1Waypoints = new List<WaypointData>()
    {
        new WaypointData(41.276339f, 1.988432f, 0f, 65f), 
        new WaypointData(41.276388f, 1.988486f, 0f, 40f), 
        new WaypointData(41.276350f, 1.988629f, 0f, 110f), 
        new WaypointData(41.276345f, 1.988754f, 0f, 80f), 
        new WaypointData(41.276410f, 1.988804f, 0f, 0f), 
        new WaypointData(41.276493f, 1.988856f, 0f, 20f), 
        new WaypointData(41.276481f, 1.989005f, 0f, 80f), 
    };

    private List<WaypointData> circuit2Waypoints = new List<WaypointData>()
    {
        new WaypointData(41.276389f, 1.988323f, 0f, 40f),
        new WaypointData(41.276410f, 1.988411f, 0f, 70f),
        new WaypointData(41.276428f, 1.988515f, 0f, 70f),
        new WaypointData(41.276448f, 1.988600f, 0f, 70f),
        new WaypointData(41.276465f, 1.988678f, 0f, 70f),
        new WaypointData(41.276484f, 1.988741f, 0f, 70f),
        new WaypointData(41.276501f, 1.988827f, 0f, 70f),
        new WaypointData(41.276516f, 1.988900f, 0f, 70f),
        new WaypointData(41.276512f, 1.988959f, 0f, 110f),
        new WaypointData(41.276477f, 1.989017f, 0f, 160f), 
        new WaypointData(41.276403f, 1.988995f, 0f, 210f),
        new WaypointData(41.276352f, 1.988905f, 0f, 240f), 
        new WaypointData(41.276330f, 1.988813f, 0f, 240f), 
        new WaypointData(41.276300f, 1.988710f, 0f, 240f),
        new WaypointData(41.276270f, 1.988597f, 0f, 240f), 
        new WaypointData(41.276255f, 1.988507f, 0f, 240f), 
        new WaypointData(41.276249f, 1.988409f, 0f, 320f), 
    };
    public void SelectCircuit(int circuitIndex)
    {
        TemporaryWaypointStorage.SelectedCircuit = (circuitIndex == 1) ? CircuitType.Circuit1 :
                                                   (circuitIndex == 2) ? CircuitType.Circuit2 : CircuitType.None;
        Debug.Log("Selected circuit: " + TemporaryWaypointStorage.SelectedCircuit);
    }

    public void AddWaypointFromUI(WaypointData data)
    {
        waypointDataList.Add(data);
        Debug.Log("Added UI Waypoint: " + data.latitudeInput + ", " + data.longitudeInput + ", " + data.altitudeInput + ", " + data.headingInput);
    }

    public void RemoveLastWaypoint()
    {
        if (waypointDataList.Count > 0)
        {
            waypointDataList.RemoveAt(waypointDataList.Count - 1);
            Debug.Log("Removed last UI waypoint.");
        }
    }

    public void ClearUIWaypoints()
    {
        waypointDataList.Clear();
    }

    public void SpawnWaypoints(Vector3 dronePosition, float baseLat, float baseLon, float baseHeading)
    {
        Debug.Log("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        if (waypointsSpawned) return;

        foreach (Vector3 pos in waypointPositions) //Spawn dels waypoints escrits a l'inspector
        {
            // Ajusta la rotación del aro
            Quaternion rotation = Quaternion.Euler(90, 0, 0);
            GameObject waypoint = Instantiate(waypointPrefab, pos, rotation, waypointsContainer);
            spawnedWaypoints.Add(waypoint);
            Debug.Log("Spawned waypoint at: " + pos);
        }

        foreach (WaypointData data in TemporaryWaypointStorage.SavedWaypoints) //spawn dels waypoints del panel
        {
            float latDiff = (data.latitudeInput - baseLat) * 111000f;
            float lonDiff = (data.longitudeInput - baseLon) * 111000f * Mathf.Cos(baseLat * Mathf.Deg2Rad);
            Vector3 relativePosition = new Vector3(lonDiff, data.altitudeInput, latDiff);

            Quaternion rotation = Quaternion.Euler(90, data.headingInput, 0);
            GameObject waypoint = Instantiate(waypointPrefab, relativePosition, rotation, waypointsContainer);

            spawnedWaypoints.Add(waypoint);

            Debug.Log("LATDIF " + latDiff + "lat input= " + data.latitudeInput + " baseLAT= " + baseLat);
            Debug.Log("Spawned UI Waypoint at: " + waypoint);
        }

        //Waypoints provinenets del circuits predefinits
        List<WaypointData> selectedCircuitWaypoints = null;

        switch (TemporaryWaypointStorage.SelectedCircuit)
        {
            case CircuitType.Circuit1:
                selectedCircuitWaypoints = circuit1Waypoints;
                break;
            case CircuitType.Circuit2:
                selectedCircuitWaypoints = circuit2Waypoints;
                break;
        }

        if (selectedCircuitWaypoints != null)
        {
            foreach (WaypointData data in selectedCircuitWaypoints)
            {
                float latDiff = (data.latitudeInput - baseLat) * 111000f;
                float lonDiff = (data.longitudeInput - baseLon) * 111000f * Mathf.Cos(baseLat * Mathf.Deg2Rad);
                Vector3 relativePosition = new Vector3(lonDiff, data.altitudeInput, latDiff);

                Quaternion rotation = Quaternion.Euler(90, data.headingInput, 0);
                GameObject waypoint = Instantiate(waypointPrefab, relativePosition, rotation, waypointsContainer);

                spawnedWaypoints.Add(waypoint);
                Debug.Log("Spawned CIRCUIT Waypoint at: " + relativePosition);
            }
        }

        waypointsSpawned = true;
    }

}
