using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuScript : MonoBehaviour
{
    public void PlayMenu()
    {
        SceneManager.LoadSceneAsync("PlayMenu");
    }

    public void WaypointsMenu()
    {
        TemporaryWaypointStorage.SavedWaypoints.Clear();
        TemporaryWaypointStorage.SelectedCircuit = CircuitType.None;
        SceneManager.LoadSceneAsync("WaypointsMenu");
    }
    public void MenuButton()
    {
        SceneManager.LoadSceneAsync("Menu");
    }

    public void QuitGame()
    {
        Application.Quit();
    }
}
